def get_wq(wq):
    if wq == "tld":
        return "屠龙刀"
    elif wq =="ytj":
        return "倚天剑"
    elif wq == "xxszs":
        return "小学生之手"
    elif wq == "xlfd":
        return "小李飞刀"
    elif wq == "bszc":
        return "冰霜之锤"
    elif wq == "hsqgz":
        return "黑色切割者"
    elif wq == "jwctk":
        return "金钨楮天棍"
    elif wq == "98K":
        return "98K"
    elif wq == "mbqt":
        return "灭霸手套"
    elif wq == "ktkj":
        return "狂徒铠甲"