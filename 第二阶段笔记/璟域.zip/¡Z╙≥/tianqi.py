# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import basicSpider
from bs4 import BeautifulSoup

city = 'beijing'
see_url = "https://www.tianqi.com/"+city+'/'
headers = [('User-agent', '')]
html = basicSpider.downloadHtml(see_url)


def get_tianqi(city,html):
    weather = []
    soup = BeautifulSoup(str(html), "html.parser")
    nowTemperature = str(soup.find_all('p',class_="now")[0]).split('<b>')[1].split('</b>')[0]
    #nowOther = soup.find_all('dd',class_='shidu')
    nowWeather =str(soup.find_all('span')[0]).split('<b>')[1].split('</b>')[0]
    weather =city+":"+nowWeather+':'+ nowTemperature+'℃'
    return weather

#<span><b>晴</b>17 ~ 33℃</span>
#<p class="now"><b>33</b><i>℃</i></p>
#<dd class="shidu"><b>湿度：8%</b><b>风向：西南风 3级</b><b>紫外线：强</b></dd>
# print(get_tianqi(city,html))