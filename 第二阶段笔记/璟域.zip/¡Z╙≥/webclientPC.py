#! /usr/bin/python3
# coding=utf-8

# 导入ＰＹＱＴ４模块调用来实现之页面间访问首页的操作
'''
    此文件通过发送get首页请求获得响应作为客户端ＰＣ端使用
'''

import sys
from PyQt4.QtWebKit import QWebView
from PyQt4.QtGui import QApplication
from PyQt4.QtCore import QUrl
# 创建app对象
app = QApplication(sys.argv)

# 创建浏览器对象
browser = QWebView()
# 获取对象的设置属性
browser.coding = browser.settings()
# 改变默认编码格式
browser.coding.setDefaultTextEncoding("UTF-8")
# 浏览器访问首页
browser.load(QUrl("http://127.0.0.1:8888/"))
# 展示收到的html文件
browser.show()
app.exec_()
