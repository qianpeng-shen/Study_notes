#注册添加用户 需要姓名，密码，性别（注册时间自动生成）
registered_user = "insert into user(name,passward,sex) values('%s','%s','%s');" % (user,passward,sex)

#每注册一个用户执行这两个函数，让user_money有你注册的用户名，并且给定初始化金币
tongbu = 'insert into user_money(name) select name from user where not exists(select * from user_money where user_money.name=user.name);'


#通过姓名查询密码 user代表给出的姓名
query_passward = "select passward from user where name='%s';" % user

#通过用户注销用户
logout_user = "delete from user where name='%s';" % user

#查询用户的金币 传入姓名
query_money = "select money from user_money where name='%s';" % user

#修改用户金币　传入姓名和修改后的金钱
alter_money = "update user_money set money=%d where name='%s';" % (money,user)

#查询武器属性
query_weapon = "select * from weapon where name='%s';" % name

#购买武器 传入的持有人名字和武器名字，武器的攻击和防御
buy_weapon = "insert into user_force values ('%s','%s');" % (name,user,gongji,fangyu)

#查询用户的武力值
query_force = "select name,sum(attack),sum(defense) from user_force where name='%s' group by name;" % user
