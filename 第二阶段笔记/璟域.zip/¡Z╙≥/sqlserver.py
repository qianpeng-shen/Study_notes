from pymysql import *


# 创建操作数据库类便于操作
class mynewsql():
    def __init__(self):
        self.fd = connect('localhost','root','123456','xiangmu')
        self.cursor = self.fd.cursor()

    # 此方法用来进行注册判定
    def clyhzc(self,user,passward,sex):
        try:
            string = "insert into user(name,passward,sex) values('%s','%s','%s');" % (user,passward,sex)
            print(string)
            self.cursor.execute(string)
            string = 'insert into user_money(name) select name from user where not exists(select * from user_money where user_money.name=user.name);'
            self.cursor.execute(string)
            self.fd.commit()
        except Exception:
            self.cursor.close()
            self.fd.close()
            return "NO"
        else:
            self.cursor.close()
            self.fd.close()
            return 'OK'

    # 此方法用来进行登录判定
    def clyhdl(self,user,passwd):
        string = "select passward from user where name='%s';" % user
        # print(string)
        self.cursor.execute(string)
        try:
            s = self.cursor.fetchone()[0]
        except TypeError:
            s = ' '
        finally:
            self.fd.commit()
            if s == passwd:
                self.cursor.close()
                self.fd.close()
                return 'OK'
            else:
                self.cursor.close()
                self.fd.close()
                return 'NO'

# 此方法用来改变用户的金币
    def get_money(self, user, money):
        string = "select money from user_money where name='%s';" % user
        self.cursor.execute(string)
        s = int(self.cursor.fetchone()[0])
        s += money
        string = "update user_money set money=%d where name='%s';" % (s, user)
        self.cursor.execute(string)
        self.fd.commit()
        self.cursor.close()
        self.fd.close()
#获得金币数量
    def get_usemoney(self,user):
        string = "select money from user_money where name='%s';" % user
        self.cursor.execute(string)
        s = int(self.cursor.fetchone()[0])
        return s

#购买武器  传入姓名  和 购买的武器
    def buy_useweapon(self,user,name):
        #查询武器的价值
        string = "select price from weapon where name='%s';" % name
        print(string)
        self.cursor.execute(string)
        self.fd.commit()
        #查到的武器价格为
        sw = int(self.cursor.fetchone()[0])
        #查询用户的金币
        string = "select money from user_money where name='%s';" % user
        self.cursor.execute(string)
        s = int(self.cursor.fetchone()[0])
        #用户的金币与价格做比较
        if s >= sw:
            #改变用户的金币数量
            ss = s - sw
            string = "update user_money set money=%d where name='%s';" % (ss, user)
            self.cursor.execute(string)
            self.fd.commit()
            #查询武器的武力值加到用户身上
            string = "select attack,defense from weapon where name='%s';" % name
            self.cursor.execute(string)
            s = self.cursor.fetchall()[0]
            s1 = s[0]
            s2 = s[1]
            string = "insert into user_force values('%s','%s',%d,%d);" % (user,name,s1,s2)
            self.cursor.execute(string)
            self.fd.commit()
            self.cursor.close()
            self.fd.close()
            print("+++++++++++++")
            return 'OK'
        else:
            return 'NO'

    #获取用户的武力值
    def get_useweapon(self,user):
        string = "select name,sum(attack),sum(defense) from user_force where name='%s';" % user
        self.cursor.execute(string)
        s = self.cursor.fetchall()[0]
        s1 = s[1]
        s2 = s[2]
        print("攻击力:%d,防御力:%d"%(s1,s2))
        return "攻击力:%d,防御力:%d"%(s1,s2)
























