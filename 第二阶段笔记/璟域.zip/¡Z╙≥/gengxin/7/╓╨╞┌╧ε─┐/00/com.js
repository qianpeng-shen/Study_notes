﻿ function $(ID){
	return document.getElementById(ID);
	}