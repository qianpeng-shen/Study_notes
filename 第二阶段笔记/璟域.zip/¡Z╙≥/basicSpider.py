# -*- coding: utf-8 -*-
"""
Created on Sat May 26 11:39:18 2018

@author: Administrator
"""

from urllib import request
from urllib import error
import time

def downloadHtml(url, num_retries=10,try_delay_time=5):
    if num_retries <= 0:
        return None
    req = request.Request(url)
    try:
        repsonse = request.urlopen(req)
    # 400-500客户端的问题, 
    # 500-600服务器的问题
    except error.URLError or error.HTTPError as e:
        print("Download Error")
        hasattr(e,'code')
        if 400<= e.code < 500:
            print("URL %s Error in Client, stauts code %d"%(url, e.code))
        elif  500<= e.code < 600:
            downloadHtml(url, num_retries-1, try_delay_time*10)
            time.sleep(try_delay_time)
    return repsonse.read().decode('utf-8')
    