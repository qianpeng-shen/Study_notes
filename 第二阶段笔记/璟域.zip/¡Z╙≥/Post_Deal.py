#!/usr/bin/python3
'''
    此文件用来处理http的post请求
'''
from tianqi import *
from wqjx import get_wq
#导入ＰＫ处理语句
from jieb import *
#　导入sql类方便查询输出库
from sqlserver import mynewsql
# 使用正则表达式进行数据处理
static = "./static"
# 定义页面的位置采用相对路径

# 对密码进行判断使用的函数
def post_deal(c,files,string):
    # 对form请求中的内容进行处理
    l = string.split("&")
    D = {}
    # 将内容和值存入字典备用
    for i in l:
        s = i.split('=')
        D[s[0]] = s[1]

    print(D)


    # 对登录操作进行返回
    if files[-10:] == "login.html":
        # 创建操作数据库的对象
        Sql_Operation = mynewsql()
        # 调用操作数据库的登录函数
        string = Sql_Operation.clyhdl(D["uname"],D["upwd"])
        # 判断数据库函数的返回值确定是否登录，未成功返回当前界面
        del Sql_Operation
        if string == "NO":
            response = "HTTP/1.1 " + "200 " + "ok\r\n\r\n"
            try:
                f = open("./static/index1.html","r")
            except:
                response = "HTTP/1.1 404 not find\r\n\r\n"
            else:
                for line in f:
                    response += line
            finally:
                return response.encode()
        # 登录成功返回游戏主界面
        elif string == "OK":
            print('++++++++++++++++++++')
            response = "HTTP/1.1 " + "200 " + "ok\r\n"
            response += "\r\n"
            try:
                f = open("./static/login.html","r")
            except:
                response = "HTTP/1.1 404 not find\r\n\r\n"
            else:
                for line in f:
                    if "张三" in line:
                        line = line.replace("张三",D["uname"],99)
                    if "天气" in line:
                        line = line.replace("天气","天气" + get_tianqi(city,html))
                    if "金币" in line:
                        Sql_Operation = mynewsql()
                        string = Sql_Operation.get_usemoney(D["uname"])
                        try:
                            string2 = Sql_Operation.get_useweapon(D['uname'])
                        except:
                            string2 = ''
                        line = line.replace("金币", ("金币" + str(string) +' ' + str(string2)))
                        del Sql_Operation
                    response += line
            finally:
                return response.encode()

    # 注册返回首页
    elif files[-10:] == "index.html":
        # 如果确认密码和输入密码不同返回当前界面
        if D["pwd1"] != D["pwd2"]:
            response = "HTTP/1.1 " + "200 " + "ok\r\n\r\n"
            try:
                f = open("./static/zhuce1.html",'r')
            except:
                response = "HTTP/1.1 404 not find\r\n\r\n"
            else:
                for line in f:
                    response += line
            finally:
                return response.encode()
        # 确认和输入相同进入数据库判定
        Sql_Operation = mynewsql()
        string = Sql_Operation.clyhzc(D["uname"],D["pwd1"],D["gender"])
        del Sql_Operation
        # 注册失败返回当前页面
        if string == "NO":
            response = "HTTP/1.1 " + "200 " + "ok\r\n\r\n"
            try:
                f = open("./static/zhuce3.html",'r')
            except:
                response = "HTTP/1.1 404 not find\r\n\r\n"
            else:
                for line in f:
                    response += line
            finally:
                return response.encode()
            # 注册成功返回首页
        elif string == "OK":
            response = "HTTP/1.1 " + "200 " + "ok\r\n\r\n"
            try:
                f = open("./static/index.html",'r')
            except:
                response = "HTTP/1.1 404 not find\r\n\r\n"
            else:
                for line in f:
                    response += line
            finally:
                return response.encode()
    
    #此条件用来进入游戏界面
    elif files[-10:] == "youxi.html":
        response = "HTTP/1.1 " + "200 " + "ok\r\n"
        response += "\r\n"
        try:
            f = open("./static/youxi.html","r")
        except:
            response = "HTTP/1.1 404 not find\r\n\r\n"
        else:

            for line in f:
                if "张三" in line:
                    line = line.replace("张三",D["uname"],99)
                if "苦咖啡四大皆空" in line:
                    line = line.replace("苦咖啡四大皆空",get_PK(D["uname"]))
                response += line
        finally:
            return response.encode()
    # 此条件用来返回主菜单
    elif files[-11:] == "login2.html":
        response = "HTTP/1.1 " + "200 " + "ok\r\n"
        response += "\r\n"
        try:
            f = open("./static/login2.html","r")
        except:
            response = "HTTP/1.1 404 not find\r\n\r\n"
        else:
            for line in f:
                if "张三" in line:
                    line = line.replace("张三",D["uname"],99)
                if "天气" in line:
                    line = line.replace("天气","天气" + get_tianqi(city,html))                    
                if "金币" in line:
                    Sql_Operation = mynewsql()
                    string = Sql_Operation.get_usemoney(D["uname"])
                    string2 = Sql_Operation.get_useweapon(D['uname'])
                    print(string2)
                    line = line.replace("金币", "金币" + str(string) +' ' + str(string2))
                    del Sql_Operation
                response += line
        finally:
            print("返回请求")
            return response.encode()

        # 此条件用来进入聊天界面
    elif files[-14:] == "liaotian2.html":
        response = "HTTP/1.1 " + "200 " + "ok\r\n"
        response += "\r\n"
        try:
            f = open("./static/liaotian2.html","r")
        except:
            response = "HTTP/1.1 404 not find\r\n\r\n"
        else:
            for line in f:
                if "张三" in line:
                    line = line.replace("张三",D["uname"],99)
                response += line
        finally:
            return response.encode()

    elif files[-14:] == "shanchang.html":
        response = "HTTP/1.1 " + "200 " + "ok\r\n"
        response += "\r\n"
        try:
            f = open("./static/shanchang.html","r")
        except:
            response = "HTTP/1.1 404 not find\r\n\r\n"
        else:
            for line in f:
                if "张三" in line:
                    line = line.replace("张三",D["uname"],99)
                response += line
        finally:
            response = response.encode()
            return response


    elif files[-13:] == "liaotian.html":
        response = "HTTP/1.1 " + "200 " + "ok\r\n"
        response += "\r\n"
        try:
            f = open("./static/liaotian.html", "r")
        except:
            response = "HTTP/1.1 404 not find\r\n\r\n"
        else:
            for line in f:
                if "张三" in line:
                    line = line.replace("张三", D["uname"], 99)
                elif "答:" in line:
                    string2 = gethf(D["mingling"])
                    line = line.replace("答:", "答:" + string2)
                response += line
        finally:
            return response.encode()

    elif files[-14:] == "liaotian3.html":
        response = "HTTP/1.1 " + "200 " + "ok\r\n"
        response += "\r\n"
        try:
            f = open("./static/liaotian3.html", "r")
        except:
            response = "HTTP/1.1 404 not find\r\n\r\n"
        else:
            for line in f:
                if "张三" in line:
                    line = line.replace("张三", D["uname"], 99)
                elif "答:" in line:
                    string2 = gethf(D["mingling"])
                    line = line.replace("答:", "答:" + string2)
                response += line
        finally:
            return response.encode()

    elif files[-15:] == "shanchang2.html":
        response = "HTTP/1.1 " + "200 " + "ok\r\n"
        response += "\r\n"
        try:
            f = open("./static/shanchang2.html","r")
        except:
            response = "HTTP/1.1 404 not find\r\n\r\n"
        else:
            Sql_Operation = mynewsql()
            string = Sql_Operation.buy_useweapon(D["uname"],D["wq"])
            del Sql_Operation
            if string == 'OK':
                for line in f:
                    if "张三" in line:
                        line = line.replace("张三",D["uname"],99)
                    if "屠龙刀" in line:
                        line = line.replace("屠龙刀",get_wq(D["wq"]),99)
                    response += line
            else:
                for line in f:
                    if "张三购买了屠龙刀" in line:
                        line = line.replace("张三购买了屠龙刀",'金币不足',99)
                    if "张三" in line:
                        line = line.replace("张三",D["uname"],99)

                    response += line

        finally:
            print(response)
            response = response.encode()
            return response