#! /usr/bin/python3
'''
    此文件用来创建库

'''
import pymysql

#1.创建数据库连接
db = pymysql.connect("localhost","root","123456",charset="utf8")
#2.创建游标对象
cursor = db.cursor()

#3.利用游标对象cursor的方法来操作数据库
cursor.execute("create database xiangmu default charset=utf8;")
db.commit()


#5.关闭游标对象
cursor.close()
#6.关闭数据库连接
db.close()


#1.创建数据库连接
db = pymysql.connect("localhost","root","123456","xiangmu",charset="utf8")
#2.创建游标对象
cursor = db.cursor()

#3.利用游标对象cursor的方法来操作数据库
cursor.execute("create table user(name char(25) not null primary key,passward char(20) not null,sex enum('M','W'),birth timestamp);")
#4.提交到数据库commit
db.commit()


#5.关闭游标对象
cursor.close()
#6.关闭数据库连接
db.close()

#1.创建数据库连接
db = pymysql.connect("localhost","root","123456","xiangmu",charset="utf8")
#2.创建游标对象
cursor = db.cursor()

#3.利用游标对象cursor的方法来操作数据库
cursor.execute("create table user_force(name char(25),weapon char(20),attack int(6),defense int(6));")
#4.提交到数据库commit
db.commit()


#5.关闭游标对象
cursor.close()
#6.关闭数据库连接
db.close()

#1.创建数据库连接
db = pymysql.connect("localhost","root","123456","xiangmu",charset="utf8")
#2.创建游标对象
cursor = db.cursor()

#3.利用游标对象cursor的方法来操作数据库
cursor.execute("create table user_money(name char(25),money int(6) default 1000,foreign key(name) references user(name) on delete cascade on update cascade);")
#4.提交到数据库commit
db.commit()


#5.关闭游标对象
cursor.close()
#6.关闭数据库连接
db.close()

#1.创建数据库连接
db = pymysql.connect("localhost","root","123456","xiangmu",charset="utf8")
#2.创建游标对象
cursor = db.cursor()

#3.利用游标对象cursor的方法来操作数据库
cursor.execute("create table weapon(name char(20),price int(6),attack int(6),defense int(6));")
#4.提交到数据库commit
db.commit()
print('-----')
cursor.execute("insert into weapon values('tld',1888,1888,222),('ytj',1682,1682,322),('xlfd',1999,2000,100),('ktkj',1822,102,2001),('hsqgz',1899,1200,999),('98K',1810,1700,50),('bszc',1777,999,999),('jwctg',1600,899,808),('mbqt',2000,2200,1),('xxszs',1000,1100,100);")
db.commit()
print('++')
#5.关闭游标对象
cursor.close()
#6.关闭数据库连接
db.close()