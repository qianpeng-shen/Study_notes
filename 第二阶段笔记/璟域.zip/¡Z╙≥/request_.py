# /usr/bin/python3
# /*coding="utf-8"*/
'''
此文件用来存储处理服务器请求并调用接口返回报文


'''
from Post_Deal import *



# 定义页面的位置采用相对路径
static = "./static"


# 定义处理函数
def request_handler(c,data):
    # 定义获取html文件在服务器上的地址
    def get_file(request_file):
        if request_file == "/":
            string = "/index.html"
        else:
            string = request_file
        # 返回html文件在服务器上的地址
        return static + string

    # 将请求按行分理
    l = data.splitlines()

    # 获取请求求
    header = l[0].split(' ')
    # 获得请求方法
    request_method = header[0]
    # 获取请求文件
    request_file = header[1]

    # 获取首页
    if request_file == "/":
        really_file = get_file(request_file)
    # 获取html文件位置
    else:
        really_file = get_file(request_file)
    # 设置未找到文件为默认返回
    response_header = "HTTP/1.1 " +"404 " +"not found" + "\r\n"
    response_ranks = "\r\n"
    # 请求为get的时候的返回响应
    if request_method == "GET":
        if really_file[-4:] == "html":
            try:
                # 打开文件
                f = open(really_file,"r")
            except:
                # 失败返回未找到错误信息
                response = response_header + response_ranks + "<h1>页面未找到<h1>"
            else:
                # 打开成功文件
                response_header = "HTTP/1.1 " + "200 " + "ok" + "\r\n"
                response = response_header + response_ranks
                print(f)
                for line in f:
                    response += line
            finally:
                # 返回响应报文
                f.close()
                return response.encode()
        elif really_file[-3:] == "png":
            try:
                # 打开文件
                f = open(really_file,"rb")
            except:
                # 失败返回未找到错误信息
                response = response_header + response_ranks + "<h1>页面未找到<h1>"
            else:
                # 打开成功文件
                response_header = "HTTP/1.1 " + "200 " + "ok" + "\r\n"
                response = (response_header + response_ranks).encode()
                print(f)
                for line in f:
                    response += line
            finally:
                # 返回响应报文
                f.close()
                return response
        elif really_file[-3:] == "jpg":
            try:
                # 打开文件
                f = open(really_file,"rb")
            except:
                # 失败返回未找到错误信息
                response = response_header + response_ranks + "<h1>页面未找到<h1>"
            else:
                # 打开成功文件
                response_header = "HTTP/1.1 " + "200 " + "ok" + "\r\n"
                response = (response_header + response_ranks).encode()
                print(f)
                for line in f:
                    response += line
            finally:
                # 返回响应报文
                f.close()
                return response
        elif really_file[-3:] == "css":
            try:
                # 打开文件
                f = open(really_file,"rb")
            except:
                # 失败返回未找到错误信息
                response = response_header + response_ranks + "<h1>页面未找到<h1>"
            else:
                # 打开成功文件
                response_header = "HTTP/1.1 " + "200 " + "ok" + "\r\n"
                response = (response_header + response_ranks).encode()
                print(f)
                for line in f:
                    response += line
            finally:
                # 返回响应报文
                f.close()
                return response
        elif really_file[-3:] == ".js":
            try:
                # 打开文件
                f = open(really_file,"rb")
            except:
                # 失败返回未找到错误信息
                response = response_header + response_ranks + "<h1>页面未找到<h1>"
            else:
                # 打开成功文件
                response_header = "HTTP/1.1 " + "200 " + "ok" + "\r\n"
                response = (response_header + response_ranks).encode()
                print(f)
                for line in f:
                    response += line
            finally:
                # 返回响应报文
                f.close()
                return response
        elif really_file[-3:] == "ico":
            try:
                # 打开文件
                f = open(really_file,"rb")
            except:
                # 失败返回未找到错误信息
                response = response_header + response_ranks + "<h1>页面未找到<h1>"
            else:
                # 打开成功文件
                response_header = "HTTP/1.1 " + "200 " + "ok" + "\r\n"
                response = (response_header + response_ranks).encode()
                print(f)
                for line in f:
                    response += line
                f.close()
        elif really_file[-3:] == "gif":
            try:
                # 打开文件
                f = open(really_file,"rb")
            except:
                # 失败返回未找到错误信息
                response = response_header + response_ranks + "<h1>页面未找到<h1>"
            else:
                # 打开成功文件
                response_header = "HTTP/1.1 " + "200 " + "ok" + "\r\n"
                response = (response_header + response_ranks).encode()
                print(f)
                for line in f:
                    response += line

            finally:
                # 返回响应报文
                f.close()
                return response



    # 将post请求解决方案进行导入
    elif request_method == "POST":
        s = post_deal(c,really_file,l[-1])
        return s



        








        


