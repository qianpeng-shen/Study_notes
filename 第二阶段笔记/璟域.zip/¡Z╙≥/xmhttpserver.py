# /usr/bin/python3
# /*coding="utf-8"*/
'''
此文件用来获取获取服务器请求
为主程序
并调用请求处理方法对服务器发来的请求进行处理
因需要调用全局变量所以采用多进程技术

'''


# 调用主程序所需要的模块
from socket import *
from multiprocessing import Process
import sys
# 将处理函数进行引用
from request_ import request_handler
from signal import *


# 创建服务器类
class HttpServer(object):

# 创建服务器用户套接字列表

# 初始化类对象,创建套接字，将端口绑定成为类属性
    def __init__(self,post):
        self.socktd = socket()
        self.post = post
        self.L = []

# 绑定对象的地址
    def bind(self):
        self.socktd.bind(("0.0.0.0",self.post))
#设置端口可重用
        self.socktd.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)

# 开启对象套接字的监听
    def listen(self):
        self.socktd.listen(100)

# 等待客户端连接，使用协程进行数据处理
    def start(self):
        self.bind()
        self.listen()
        # 无视子进程信号，防止出现僵尸进程
        signal(SIGCHLD,SIG_IGN)
        while True:
            # 出现错误关闭连接套接字，并重新循环
            try:
                c,addr = self.socktd.accept()
            except Exception:
                c.close()
                continue
            else:
                # 创建子进程
                s1 = Process(target=self.handler,args=((self.socktd,c,)))
                self.get_user(c)
                s1.start()


# 将进程所需的函数定义为静态方法放入类中
    @staticmethod
    def handler(socktd,c):
        socktd.close()
        print("---------")
        while True:
            data = c.recv(1024).decode("utf8")
            response = request_handler(c,data)
            c.send(response)








# 创建类方法，修改类变量,将用户存于类变量中
    def get_user(self,c):
        self.L.append(c)

# 创建类方法，删除离开的用户
    def rm_user(self,c):
        self.L.remove(c)


# 删除对象函数中关闭套接字
    def __del__(self):
        self.socktd.close()








if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("please input POST")
    else:
        server = HttpServer(int(sys.argv[1]))
        server.start()