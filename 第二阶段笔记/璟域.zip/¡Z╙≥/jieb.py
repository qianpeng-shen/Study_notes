#!/usr/bin/python3
'''
此模块用来分解关键字词和生成ＰＫ语句

'''
import urllib.request
import jieba
from random import randint
from sqlserver import mynewsql

# 此函数获取机器人回复信息


def gethf(value):
    value = urllib.request.unquote(value)
    print(value)
    L = []
    a = jieba.cut(value)
    for i in a:
        L.append(i)
    print(L)

    def get_own(L):
        if not L:
            return "你说什么呀！？"
        if len(L) == 1:
            q = L[0]
        else:
            s = randint(0, len(L))
            q = L[s]
        L.remove(q)
        print(L)
        f = open("wendazhishi.txt", 'r')
        while True:
            fl = f.readline()
            if not fl:
                return get_own(L)
            try:
                LL = fl.split(',')
                name = LL[0]
                knows = LL[1]
            except:
                continue
            if q in name:
                return knows
            else:
                continue
    try:
        s = get_own(L)
    except:
        s = "你说什么呀？"
    return s


L = ["%s一个闪身，躲过一刀，并以迅雷不及掩耳盗铃响叮当之势一个\
    大招秒了%s", "%s使出一剑西来天外飞仙,%s倒地而亡", "\
%s一个闪现Q打出血怒，接着平A几下大招收了%s的人头", "\
%s赞满被动，站撸%s，将其反杀", "%s一个沉默打断%s的技能，\
    将其活活A死", "%s一个超远距离大招，将躲在草丛里残血的%s击杀", "\
%s背着农药绕着%s一顿跑，将其活活毒死"]


# 此函数获取ＰＫ结果
def get_PK(user):
    f = open("renwu.txt", "r").read()
    LL = f.split("\n")
    npc = LL[randint(0, len(LL))]
    string = L[randint(0, 6)]
    money = randint(0, 100)
    ss = (string % (user, npc))
    jl = ""
    if len(ss) > 27:
        jl += ss[:27]
        jl += "<br>"
        jl += ss[27:]
    else:
        jl = ss
    print(jl)
    jl += ("<br>" + ("并获得了%s金币" % money))

    newSQL = mynewsql()
    newSQL.get_money(user, money)
    del newSQL

    return jl



